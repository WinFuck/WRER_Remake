﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Registry_Reseter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text == "") //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
            {
                label2.Text = "Wpisany kod: nie jest poprawny."; //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
                MessageBox.Show("Kod jest nie prawdziwy. Wpisz kod ponownie.", "WRER Remastered", MessageBoxButtons.OK, MessageBoxIcon.Error); //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
            }

            else if(textBox1.Text == "DPH2V-TTNVB-4X9Q3-TJR4H-KHJW4") //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
            {
                label2.Text = "Wpisany kod: jest poprawny."; //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
                MessageBox.Show("Kod jest prawdziwy. Aplikacja za kazdym uruchomieniem bedzie potrzebowala kodu aktywacyjnego.", "WRER Remastered", MessageBoxButtons.OK, MessageBoxIcon.Information);         //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
                timer1.Start(); //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
            }

            else if (textBox1.Text == "VK7JG-NPHTM-C97JM-9MPGT-3V66T") //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
            {
                label2.Text = "Wpisany kod: jest poprawny."; //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
                MessageBox.Show("Kod jest prawdziwy. Aplikacja za kazdym uruchomieniem bedzie potrzebowala kodu aktywacyjnego.", "WRER Remastered", MessageBoxButtons.OK, MessageBoxIcon.Information);         //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
                timer1.Start(); //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
            }

            else if (textBox1.Text == "W269N-WFGWX-YVC9B-4J6C9-T83GX") //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
            {
                label2.Text = "Wpisany kod: jest poprawny."; //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
                MessageBox.Show("Kod jest prawdziwy. Aplikacja za kazdym uruchomieniem bedzie potrzebowala kodu aktywacyjnego.", "WRER Remastered", MessageBoxButtons.OK, MessageBoxIcon.Information);         //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
                timer1.Start(); //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
            }

            else if (textBox1.Text == "MH37W-N47XK-V7XM9-C7227-GCQG9") //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
            {
                label2.Text = "Wpisany kod: jest poprawny."; //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
                MessageBox.Show("Kod jest prawdziwy. Aplikacja za kazdym uruchomieniem bedzie potrzebowala kodu aktywacyjnego.", "WRER Remastered", MessageBoxButtons.OK, MessageBoxIcon.Information);         //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
                timer1.Start(); //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
            }

            else if (textBox1.Text == "TX9XD-98N7V-6WMQ6-BX7FG-H8Q99") //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
            {
                label2.Text = "Wpisany kod: jest poprawny."; //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
                MessageBox.Show("Kod jest prawdziwy. Aplikacja za kazdym uruchomieniem bedzie potrzebowala kodu aktywacyjnego.", "WRER Remastered", MessageBoxButtons.OK, MessageBoxIcon.Information);         //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
                timer1.Start(); //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
            }

            else if (textBox1.Text == "WNMTR-4C88C-JK8YV-HQ7T2-76DF9") //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
            {
                label2.Text = "Wpisany kod: jest poprawny."; //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
                MessageBox.Show("Kod jest prawdziwy. Aplikacja za kazdym uruchomieniem bedzie potrzebowala kodu aktywacyjnego.", "WRER Remastered", MessageBoxButtons.OK, MessageBoxIcon.Information);         //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
                timer1.Start(); //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
            }

            else if (textBox1.Text == "W269N-WFGWX-YVC9B-4J6C9-T83GX") //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
            {
                label2.Text = "Wpisany kod: jest poprawny."; //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
                MessageBox.Show("Kod jest prawdziwy. Aplikacja za kazdym uruchomieniem bedzie potrzebowala kodu aktywacyjnego.", "WRER Remastered", MessageBoxButtons.OK, MessageBoxIcon.Information);         //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
                timer1.Start(); //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
            }

            else
            {
                MessageBox.Show("Kod jest nie prawdziwy. Wpisz kod ponownie.", "WRER Remastered", MessageBoxButtons.OK, MessageBoxIcon.Error);
                label2.Text = "Wpisany kod: nie jest poprawny.";
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Stop();
            this.Hide();
            var NewForm = new Reset();
            NewForm.ShowDialog();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Przepraszamy ale aplikacja wymaga uprawnień administratora. Jesli chcesz aby wszystkie funkcje aplikacje dzialaly poprawnie uruchom aplikacje ale jako amdinistrator, Jesli uruchomiles\as ten program jako administrator mozesz zignorować ten komunikat.", "WRER Remastered", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
