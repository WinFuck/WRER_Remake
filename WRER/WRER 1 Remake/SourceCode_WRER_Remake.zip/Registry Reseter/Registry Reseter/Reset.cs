﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;
using System.Diagnostics;

namespace Registry_Reseter
{
    public partial class Reset : Form
    {
        public Reset()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            RegistryKey dis = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System");
            dis.SetValue("EnableLUA", 1, RegistryValueKind.String);
            MessageBox.Show("Kontrola Konta uzytkownika zostala wlaczona pomyslnie.", "WRER Remastered", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            RegistryKey reg3 = Registry.CurrentUser.OpenSubKey("Software\\Policies\\Microsoft\\Windows\\System");
            reg3.SetValue("DisableCMD", 0, RegistryValueKind.String);
            MessageBox.Show("Wiersz polecenia zostal wlaczony pomyslnie.", "WRER Remastered", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            RegistryKey reg2 = Registry.CurrentUser.CreateSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies");
            reg2.SetValue("SystemDisableRegistryTools", 0, RegistryValueKind.String);
            MessageBox.Show("Rejestr kluczy systemu Windows zostal wlaczony pomyslnie.", "WRER Remastered", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            RegistryKey reg1 = Registry.CurrentUser.CreateSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System");
            reg1.SetValue("DisableTaskMgr", 0, RegistryValueKind.String);
            MessageBox.Show("Menedżer Zadań systemu Windows zostal wlaczony pomyslnie.", "WRER Remastered", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            RegistryKey reg2 = Registry.CurrentUser.CreateSubKey("Control Panel\\Desktop");
            reg2.SetValue("Wallpaper", @"C:\Windows\Web\Wallpaper\Windows\img0.jpg", RegistryValueKind.String);
            MessageBox.Show("Domyślna tapeta windowsa ustawiona.", "WRER Remastered", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            RegistryKey reg4 = Registry.LocalMachine.CreateSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon\\Userinit");
            reg4.SetValue("Userinit", @"C:\Windows\system32\userinit.exe,", RegistryValueKind.String);
            MessageBox.Show("Zresetowano ustawienie userinit.exe!", "WRER Remastered", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.timer1.Start();
            this.timer2.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            this.progressBar1.Increment(1);
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            this.timer2.Stop();
            System.Diagnostics.Process.Start("restart", "/r /s 0"); //Kod zrodlowy bedzie na githubie link podam pod opisem filmu, bede musial jeszcze nad bledami popracować
        }
    }
}
