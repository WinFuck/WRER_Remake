Ten plik nie jest wirusem! Chociaz kaspersky go wykrywa jako wirus,
tutaj jest skan na virustotal: https://www.virustotal.com/gui/file/99cf4ff75aff1a1b1c1a80076c3acf0456f1b4d4b02c33f5807588ef35b6b0d5?nocache=1

Aplikacja posiada takie pliki jak: 
- WRER3_exist.dll
- WRER3_program_info.ini

jesli aplikacja nie wykryje tych powyższych plików, aplikacja moze wyrzucić błąd.
nie usuwaj tych plikow jesli chcesz aby dzialala poprawnie