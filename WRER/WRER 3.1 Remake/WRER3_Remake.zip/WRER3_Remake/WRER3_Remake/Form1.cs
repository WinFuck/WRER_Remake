﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Net;
using System.IO;

namespace WRER3_Remake
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            WebClient webClient = new WebClient();
            webClient.DownloadFile("https://downloads.malwarebytes.com/file/adwcleaner", @"C:\Users\Public\Downloads\MBAM_AdwCleaner.exe"); 
            if (File.Exists(@"C:\Users\Public\Downloads\MBAM_AdwCleaner.exe"))
            {
                System.Diagnostics.Process.Start(@"C:\Users\Public\Downloads\MBAM_AdwCleaner.exe");
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            var NewForm = new settingswrer();
            NewForm.ShowDialog();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            var NewForm = new wrerreseter();
            NewForm.ShowDialog();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            System.Diagnostics.Process.Start("taskkill", "/IM WRER3_Remake.exe /F");
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("taskkill", "/IM WRER3_Remake.exe /F");
        }
    }
}
