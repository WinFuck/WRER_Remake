﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WRER3_Remake
{
    public partial class settingswrer : Form
    {
        public settingswrer()
        {
            InitializeComponent();
        }

        private void settingswrer_Load(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (File.Exists(@"C:\Program Files\WRER3_Remake\tmp_files_cleaner.cmd"))
            {
                System.Diagnostics.Process.Start(@"C:\Program Files\WRER3_Remake\tmp_files_cleaner.cmd");
            }

            else
            {
                MessageBox.Show("Aplikacja do czyszczenia plikow tymczasowych nie zostala wykryta!", "WRER 3.0  Remastered", MessageBoxButtons.OK, MessageBoxIcon.Error);     
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (File.Exists(@"%USERPROFILE%\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup\WRER3_Remake.exe"))
            {
                File.Delete(@"%USERPROFILE%\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup\WRER3_Remake.exe");
            }

            else
            {
                MessageBox.Show("Nie wykryto zadnej aplikacji w autostarcie!", "WRER 3.0  Remastered", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Stop();
            if (File.Exists(@"C:\Program Files\WRER3_Remake\WRER3_exist.dll"))
            {

            }

            else
            {
                MessageBox.Show("Nie wykryto pliku: WRER3_exist.dll. Program zamknie sie automatycznie. ", "WRER 3.0  Remastered", MessageBoxButtons.OK, MessageBoxIcon.Error);
                System.Diagnostics.Process.Start("taskkill", "/IM WRER3_Remake.exe /F");
            }
            timer1.Start();
        }

        private void settingswrer_FormClosed(object sender, FormClosedEventArgs e)
        {
            timer1.Stop();
        }
    }
}
