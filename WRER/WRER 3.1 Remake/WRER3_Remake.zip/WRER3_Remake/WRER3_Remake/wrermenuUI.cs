﻿using System;
using System.Diagnostics;
using System.Windows.Forms;
using System.IO;

namespace WRER3_Remake
{
    public partial class wrermenuUI : Form
    {
        public wrermenuUI()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("taskkill", "/IM WRER3_Remake.exe /F");
        }

        private void wrermenuUI_Load(object sender, EventArgs e)
        {
            tmr1.Start();
        }

        private void tmr1_Tick(object sender, EventArgs e)
        {
            tmr1.Stop();
            if (File.Exists(@"C:\Program Files\WRER3_Remake\WRER3_exist.dll"))
            {

            }

            else
            {
                MessageBox.Show("Nie wykryto pliku: WRER3_exist.dll. Program zamknie sie automatycznie. ", "WRER 3.0  Remastered", MessageBoxButtons.OK, MessageBoxIcon.Error);
                System.Diagnostics.Process.Start("taskkill", "/IM WRER3_Remake.exe /F");
            }
            tmr1.Start();
        }

        private void wrermenuUI_FormClosed(object sender, FormClosedEventArgs e)
        {
            tmr1.Stop();
        }
    }
}
