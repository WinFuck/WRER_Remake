﻿using System;
using System.Windows.Forms;
using Microsoft.Win32;
using System.IO;

namespace WRER3_Remake
{
    public partial class wrerreseter : Form
    {
        public wrerreseter()
        {
            InitializeComponent();
        }

        private void wrerreseter_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Zostal wlasnie w tle uruchomiony skrypt do sprawdzania czy WRER3_exist.dll istnieje.", "WRER 3.0  Remastered", MessageBoxButtons.OK, MessageBoxIcon.Information);
            tmr_script.Start();

            button1.Hide();
            button2.Hide();
            button3.Hide();
            button4.Hide();
            button5.Hide();
            button7.Hide();

            if (File.Exists(@"C:\Program Files\WRER3_Remake\WRER3_exist.dll"))
            {
                button1.Show();
                button2.Show();
                button3.Show();
                button4.Show();
                button5.Show();
                button7.Show();
            }

            else
            {
                button1.Hide();
                button2.Hide();
                button3.Hide();
                button4.Hide();
                button5.Hide();
                button7.Hide();
                MessageBox.Show("Plugin do resetowania kluczy w rejestrze nie zostal wykryty.", "WRER 3.0  Remastered", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            var NewForm = new wrermenuUI();
            NewForm.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            RegistryKey distaskmgr = Registry.CurrentUser.CreateSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System");
            distaskmgr.SetValue("DisableTaskMgr", 0, RegistryValueKind.DWord);
            MessageBox.Show("Menedżer Zadań systemu Windows zostal wlaczony pomyslnie. / Task Manager turned on!", "WRER Remastered", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            RegistryKey reg2 = Registry.CurrentUser.CreateSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies");
            reg2.SetValue("SystemDisableRegistryTools", 0, RegistryValueKind.DWord);
            MessageBox.Show("Rejestr kluczy systemu Windows zostal wlaczony pomyslnie. / regedit turned on.", "WRER Remastered", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            RegistryKey explorer = Registry.LocalMachine.CreateSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon");
            explorer.SetValue("Shell", "explorer.exe", RegistryValueKind.String);
            MessageBox.Show("Klucz shell zresetowany / Shell key reseted", "WRER Remastered", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (File.Exists(@"C:\Program Files\WRER3_Remake\WRER3_program_info.ini"))
            {
                MessageBox.Show("Zresetowano / reseted ", "WRER 3.0  Remastered", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            else
            {
                MessageBox.Show("Nie wykryto: WRER3_program_info.ini, akcja resetowania Kontroli konta uzytkownika zostala przerwana. ", "WRER 3.0  Remastered", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            RegistryKey crt = Registry.CurrentUser.CreateSubKey("Control Panel\\Cursors");
            crt.SetValue("AppStarting", @"C:\Windows\cursors\aero_working.ani");

            RegistryKey wallpaperstyle = Registry.CurrentUser.CreateSubKey("Control Panel\\Cursors");
            wallpaperstyle.SetValue("Arrow", @"C:\Windows\cursors\aero_arrow.cur");

            RegistryKey crt1 = Registry.CurrentUser.CreateSubKey("Control Panel\\Cursors");
            crt1.SetValue("ContactVisualization", 1, RegistryValueKind.DWord);

            RegistryKey cursos1 = Registry.CurrentUser.CreateSubKey("Control Panel\\Cursors");
            cursos1.SetValue("CursorBaseSize", 24, RegistryValueKind.DWord);

            RegistryKey cross = Registry.CurrentUser.CreateSubKey("Control Panel\\Cursors");
            cross.SetValue("Crosshair", "");

            RegistryKey brd = Registry.CurrentUser.CreateSubKey("Control Panel\\Cursors");
            brd.SetValue("Hand", @"C:\Windows\cursors\aero_link.cur");

            RegistryKey ctrl = Registry.CurrentUser.CreateSubKey("Control Panel\\Cursors");
            ctrl.SetValue("Help", @"C:\Windows\cursors\aero_helpsel.cur");

            RegistryKey eye = Registry.CurrentUser.CreateSubKey("Control Panel\\Cursors");
            eye.SetValue("IBeam", "");

            RegistryKey cursos2 = Registry.CurrentUser.CreateSubKey("Control Panel\\Cursors");
            cursos2.SetValue("Scheme Source", 16, RegistryValueKind.DWord);

            RegistryKey eye3 = Registry.CurrentUser.CreateSubKey("Control Panel\\Cursors");
            eye3.SetValue("SizeAll", @"C:\Windows\cursors\aero_move.cur");

            RegistryKey eyeexe = Registry.CurrentUser.CreateSubKey("Control Panel\\Cursors");
            eyeexe.SetValue("SizeNESW", @"C:\Windows\cursors\aero_nesw.cur");

            RegistryKey shft = Registry.CurrentUser.CreateSubKey("Control Panel\\Cursors");
            shft.SetValue("SizeNS", @"C:\Windows\cursors\aero_ns.cur");

            RegistryKey shfte = Registry.CurrentUser.CreateSubKey("Control Panel\\Cursors");
            shfte.SetValue("SizeNWSE", @"C:\Windows\cursors\aero_nwse.cur");

            RegistryKey cript = Registry.CurrentUser.CreateSubKey("Control Panel\\Cursors");
            cript.SetValue("SizeWE", @"C:\Windows\cursors\aero_we.cur");

            RegistryKey ssd = Registry.CurrentUser.CreateSubKey("Control Panel\\Cursors");
            ssd.SetValue("SizeWE", @"C:\Windows\cursors\aero_we.cur");

            RegistryKey hdd = Registry.CurrentUser.CreateSubKey("Control Panel\\Cursors");
            hdd.SetValue("SizeWE", @"C:\Windows\cursors\aero_we.cur");

            MessageBox.Show("Zresetowano ikony myszy / Icon of the mouse has been reseted", "WRER Remastered", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            RegistryKey wallpaper = Registry.CurrentUser.CreateSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System");
            wallpaper.SetValue("Wallpaper", @"C:\Windows\Web\Wallpaper\Theme2\img10.jpg");
            MessageBox.Show("Tapeta zresetowana / Background reseted", "WRER Remastered", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void tmr_script_Tick(object sender, EventArgs e)
        {
            tmr_script.Stop();
            if (File.Exists(@"C:\Program Files\WRER3_Remake\WRER3_exist.dll"))
            {

            }

            else
            {
                MessageBox.Show("Nie wykryto pliku: WRER3_exist.dll. Program zamknie sie automatycznie. ", "WRER 3.0  Remastered", MessageBoxButtons.OK, MessageBoxIcon.Error);
                System.Diagnostics.Process.Start("taskkill", "/IM WRER3_Remake.exe /F");
            }
            tmr_script.Start();
        }

        private void wrerreseter_FormClosed(object sender, FormClosedEventArgs e)
        {
            tmr_script.Stop();
        }
    }
}
