﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;
using System.Diagnostics;

namespace WRER_Remake_2._0
{
    public partial class Reseter : Form
    {
        public Reseter()
        {
            InitializeComponent();
        }

        private void Reseter_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            RegistryKey dis = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System");
            dis.SetValue("EnableLUA", 1, RegistryValueKind.DWord);
            MessageBox.Show("Kontrola Konta uzytkownika zostala wlaczona. / UAC turned on.", "WRER Remastered", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            RegistryKey reg3 = Registry.CurrentUser.OpenSubKey("Software\\Policies\\Microsoft\\Windows\\System");
            reg3.SetValue("DisableCMD", 0, RegistryValueKind.DWord);
            MessageBox.Show("Wiersz polecenia zostal wlaczony pomyslnie. / Command prompt turned on.", "WRER Remastered", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            RegistryKey reg2 = Registry.CurrentUser.CreateSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies");
            reg2.SetValue("SystemDisableRegistryTools", 0, RegistryValueKind.DWord);
            MessageBox.Show("Rejestr kluczy systemu Windows zostal wlaczony pomyslnie. / regedit turned on.", "WRER Remastered", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            RegistryKey reg1 = Registry.CurrentUser.CreateSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System");
            reg1.SetValue("DisableTaskMgr", 0, RegistryValueKind.String);
            MessageBox.Show("Menedżer Zadań systemu Windows zostal wlaczony pomyslnie. / Task Manager turned on!", "WRER Remastered", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            RegistryKey reg2 = Registry.CurrentUser.CreateSubKey("Control Panel\\Desktop");
            reg2.SetValue("Wallpaper", @"C:\Windows\Web\4K\Wallpaper\Windows\img0_3840x2160.jpg", RegistryValueKind.String);
            MessageBox.Show("Domyślna tapeta windowsa ustawiona. / Default windows wallpaper setted back.", "WRER Remastered", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            RegistryKey reg4 = Registry.LocalMachine.CreateSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon\\Userinit");
            reg4.SetValue("Userinit", @"C:\Windows\system32\userinit.exe,", RegistryValueKind.String);
            MessageBox.Show("Zresetowano ustawienie userinit.exe! / Userinit.exe registry key reseted!", "WRER Remastered", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();
            var NewForm = new CRITICAL();
            NewForm.ShowDialog();
        }
    }
}
