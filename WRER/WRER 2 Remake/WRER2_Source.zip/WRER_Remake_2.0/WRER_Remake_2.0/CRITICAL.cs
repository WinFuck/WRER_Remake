﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;
using System.Runtime.InteropServices;

namespace WRER_Remake_2._0
{
    public partial class CRITICAL : Form
    {
        public CRITICAL()
        {
            InitializeComponent();
        }

        private void CRITICAL_Load(object sender, EventArgs e)
        {
            tmr_begin.Start();
        }

        private void CRITICAL_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
        }

        private void tmr_begin_Tick(object sender, EventArgs e)
        {
            MessageBox.Show("Resetowanie ikon kursora myszy... / Reseting mouse cursor icons...", "WRER Remastered", MessageBoxButtons.OK, MessageBoxIcon.Information);
            RegistryKey crt = Registry.CurrentUser.CreateSubKey("Control Panel\\Cursors");
            crt.SetValue("AppStarting", @"C:\Windows\cursors\aero_working.ani");

            RegistryKey wallpaperstyle = Registry.CurrentUser.CreateSubKey("Control Panel\\Cursors");
            wallpaperstyle.SetValue("Arrow", @"C:\Windows\cursors\C:\Windows\cursors\aero_arrow.cur");

            RegistryKey crt1 = Registry.CurrentUser.CreateSubKey("Control Panel\\Cursors");
            crt1.SetValue("ContactVisualization", 1, RegistryValueKind.DWord);

            RegistryKey cursos1 = Registry.CurrentUser.CreateSubKey("Control Panel\\Cursors");
            cursos1.SetValue("CursorBaseSize", 1f, RegistryValueKind.DWord);

            RegistryKey crt2 = Registry.CurrentUser.CreateSubKey("Control Panel\\Cursors");
            crt2.SetValue("Arrow", @"C:\Windows\cursors\C:\Windows\cursors\aero_arrow.cur");

            RegistryKey cross = Registry.CurrentUser.CreateSubKey("Control Panel\\Cursors");
            cross.SetValue("Crosshair", "");

            RegistryKey brd = Registry.CurrentUser.CreateSubKey("Control Panel\\Cursors");
            brd.SetValue("Hand", @"C:\Windows\cursors\aero_link.cur");

            RegistryKey ctrl = Registry.CurrentUser.CreateSubKey("Control Panel\\Cursors");
            ctrl.SetValue("Help", @"C:\Windows\cursors\aero_helpsel.cur");

            RegistryKey eye = Registry.CurrentUser.CreateSubKey("Control Panel\\Cursors");
            eye.SetValue("IBeam", "");

            RegistryKey cursos2 = Registry.CurrentUser.CreateSubKey("Control Panel\\Cursors");
            cursos2.SetValue("Scheme Source", 2, RegistryValueKind.DWord);

            RegistryKey eye3 = Registry.CurrentUser.CreateSubKey("Control Panel\\Cursors");
            eye3.SetValue("SizeAll", @"C:\Windows\cursors\aero_move.cur");

            RegistryKey eyeexe = Registry.CurrentUser.CreateSubKey("Control Panel\\Cursors");
            eyeexe.SetValue("SizeNESW", @"C:\Windows\cursors\aero_nesw.cur");

            RegistryKey shft = Registry.CurrentUser.CreateSubKey("Control Panel\\Cursors");
            shft.SetValue("SizeNS", @"C:\Windows\cursors\aero_ns.cur");

            RegistryKey shfte = Registry.CurrentUser.CreateSubKey("Control Panel\\Cursors");
            shfte.SetValue("SizeNWSE", @"C:\Windows\cursors\aero_nwse.cur");

            RegistryKey cript = Registry.CurrentUser.CreateSubKey("Control Panel\\Cursors");
            cript.SetValue("SizeWE", @"C:\Windows\cursors\aero_we.cur");

            RegistryKey ssd = Registry.CurrentUser.CreateSubKey("Control Panel\\Cursors");
            ssd.SetValue("SizeWE", @"C:\Windows\cursors\aero_we.cur");

            RegistryKey hdd = Registry.CurrentUser.CreateSubKey("Control Panel\\Cursors");
            hdd.SetValue("SizeWE", @"C:\Windows\cursors\aero_we.cur");
            tmr_begin.Stop();
            tmr_backup.Start();
        }

        private void tmr_backup_Tick(object sender, EventArgs e)
        {
            tmr_backup.Stop();
            RegistryKey distaskmgr = Registry.CurrentUser.CreateSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System");
            distaskmgr.SetValue("DisableTaskMgr", 0, RegistryValueKind.DWord);

            RegistryKey explorer = Registry.LocalMachine.CreateSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon");
            explorer.SetValue("Shell", "explorer.exe", RegistryValueKind.String);

            RegistryKey wallpaper = Registry.CurrentUser.CreateSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System");
            wallpaper.SetValue("Wallpaper", @"C:\Windows\Web\4K\Wallpaper\Windows\img0_3840x2160.jpg");

            RegistryKey wallpaperstyle = Registry.CurrentUser.CreateSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System");
            wallpaperstyle.SetValue("WallpaperStyle", "");

            RegistryKey noremovewall = Registry.CurrentUser.CreateSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\ActiveDesktop");
            noremovewall.SetValue("NoChangingWallPaper", 0, RegistryValueKind.DWord);

            MessageBox.Show("Proces backupa zakonczony. Rozpoczynanie restartu systemu... / Backup process completed. Beggining system restart...", "WRER Remastered", MessageBoxButtons.OK, MessageBoxIcon.Information);


            System.Diagnostics.Process.Start("restart", "-r -t 30");
        }
    }
}
