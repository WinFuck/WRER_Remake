﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WRER_Remake_2._0
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            //ICON PATH: C:\Windows\Installer\{41E85393-7ED3-4C54-AC25-51F8CDF39CDF}
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Application error: 0x00001 - Funkcja aplikacji nie zostala wykryta.", "WRER Remastered", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Application error: 0x0000000069 - Funkcja aplikacji nie zostala wykryta.", "WRER Remastered", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "") //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
            {
                label2.Text = "Activation code: ERROR."; //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
                MessageBox.Show("Kod nie zostal wykryty jako poprawny. Code has been detected as incorrect!", "WRER Remastered", MessageBoxButtons.OK, MessageBoxIcon.Error); //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
            }

            else if (textBox1.Text == "DPH2V-TTNVB-4X9Q3-TJR4H-KHJW4") //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
            {
                label2.Text = "Activation code: <DPH2V-TTNVB-4X9Q3-TJR4H-KHJW4>"; //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
                MessageBox.Show("Kod wykryty jako prawidlowy! Code is detected as correct!", "WRER Remastered", MessageBoxButtons.OK, MessageBoxIcon.Information);         //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
                timer1.Start(); //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
                button3.Hide();
                button2.Hide();
                button1.Hide();
            }

            else if (textBox1.Text == "VK7JG-NPHTM-C97JM-9MPGT-3V66T") //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
            {
                label2.Text = "Activation code: <VK7JG-NPHTM-C97JM-9MPGT-3V66T>"; //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
                MessageBox.Show("Kod wykryty jako prawidlowy! Code is detected as correct!", "WRER Remastered", MessageBoxButtons.OK, MessageBoxIcon.Information);         //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
                timer1.Start(); //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
                button3.Hide();
                button2.Hide();
                button1.Hide();
            }

            else if (textBox1.Text == "W269N-WFGWX-YVC9B-4J6C9-T83GX") //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
            {
                label2.Text = "Activation code: <W269N-WFGWX-YVC9B-4J6C9-T83GX>"; //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
                MessageBox.Show("Kod wykryty jako prawidlowy! Code is detected as correct!", "WRER Remastered", MessageBoxButtons.OK, MessageBoxIcon.Information);         //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
                timer1.Start(); //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
                button3.Hide();
                button2.Hide();
                button1.Hide();
            }

            else if (textBox1.Text == "MH37W-N47XK-V7XM9-C7227-GCQG9") //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
            {
                label2.Text = "Activation code: <MH37W-N47XK-V7XM9-C7227-GCQG9>"; //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
                MessageBox.Show("Kod wykryty jako prawidlowy! Code is detected as correct!", "WRER Remastered", MessageBoxButtons.OK, MessageBoxIcon.Information);         //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
                timer1.Start(); //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
                button3.Hide();
                button2.Hide();
                button1.Hide();
            }

            else if (textBox1.Text == "TX9XD-98N7V-6WMQ6-BX7FG-H8Q99") //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
            {
                label2.Text = "Activation code: <TX9XD-98N7V-6WMQ6-BX7FG-H8Q99>"; //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
                MessageBox.Show("Kod wykryty jako prawidlowy! Code is detected as correct!", "WRER Remastered", MessageBoxButtons.OK, MessageBoxIcon.Information);         //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
                timer1.Start(); //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
                button3.Hide();
                button2.Hide();
                button1.Hide();
            }

            else if (textBox1.Text == "WNMTR-4C88C-JK8YV-HQ7T2-76DF9") //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
            {
                label2.Text = "Activation code: <WNMTR-4C88C-JK8YV-HQ7T2-76DF9>"; //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
                MessageBox.Show("Kod wykryty jako prawidlowy! Code is detected as correct!", "WRER Remastered", MessageBoxButtons.OK, MessageBoxIcon.Information);         //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
                timer1.Start(); //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
                button3.Hide();
                button2.Hide();
                button1.Hide();
            }

            else if (textBox1.Text == "W269N-WFGWX-YVC9B-4J6C9-T83GX") //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
            {
                label2.Text = "Activation code: <W269N-WFGWX-YVC9B-4J6C9-T83GX>."; //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
                MessageBox.Show("Kod wykryty jako prawidlowy! Code is detected as correct!", "WRER Remastered", MessageBoxButtons.OK, MessageBoxIcon.Information);         //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
                timer1.Start(); //TEGO NIE ZMIENIAĆ BO NIE BEDZIE CHODZIĆ
                button3.Hide();
                button2.Hide();
                button1.Hide();
            }

            else
            {
                MessageBox.Show("Kod nie zostal wykryty jako poprawny. Code has been detected as incorrect!", "WRER Remastered", MessageBoxButtons.OK, MessageBoxIcon.Error);
                label2.Text = "Activation code: <>";
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Stop();
            this.Hide();
            var NewForm = new Reseter();
            NewForm.ShowDialog();
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}
