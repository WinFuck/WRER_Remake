﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WRER4_Remake
{
    public partial class registerAcc : Form
    {
        public registerAcc()
        {
            InitializeComponent();
        }

        private void registerAcc_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Hide();
            var NewForm = new Form1();
            NewForm.ShowDialog();
        }
    }
}
