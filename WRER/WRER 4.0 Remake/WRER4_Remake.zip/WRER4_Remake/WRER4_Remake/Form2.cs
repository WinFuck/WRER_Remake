﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;
using WRER4_Remake.Properties;
using System.Net;

namespace WRER4_Remake
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Process.Start("https://www.youtube.com/channel/UCw8op7-zf18JS4KFVP_Vkvg");
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            if (File.Exists(@"C:\Program Files\WRER_4_Remake\program_Information_Keys_reset.dll"))
            {
                this.Hide();
                var NewForm = new Keysreset();
                NewForm.ShowDialog();
            }

            else
            {
                MessageBox.Show("ACCESS DENIED. - File not be detected.", "WRER Security", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            if (File.Exists(@"C:\Program Files\WRER_4_Remake\program_Information.dll"))
            {
                this.Hide();
                var NewForm = new settings();
                NewForm.ShowDialog();
            }

            else
            {
                MessageBox.Show("ACCESS DENIED. - File not be detected.", "WRER Security", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            WebClient webClient = new WebClient();
            webClient.DownloadFile("https://downloads.malwarebytes.com/file/adwcleaner", @"C:\Users\Public\Downloads\MBAM_AdwCleaner.exe");
            if (File.Exists(@"C:\Users\Public\Downloads\MBAM_AdwCleaner.exe"))
            {
                System.Diagnostics.Process.Start(@"C:\Users\Public\Downloads\MBAM_AdwCleaner.exe");
            }
        }

        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            Process.Start("taskkill", "/IM WRER4_Remake.exe /F");
        }
    }
}
