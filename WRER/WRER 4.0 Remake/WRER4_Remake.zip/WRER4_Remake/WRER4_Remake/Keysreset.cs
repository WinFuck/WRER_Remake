﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;
using Microsoft.Win32;

namespace WRER4_Remake
{
    public partial class Keysreset : Form
    {
        public Keysreset()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(File.Exists(@"C:\Program Files\WRER_4_Remake\setup.dll"))
            {
                string cur_backup_reg = @"C:\Program Files\WRER_4_Remake\cur_Backup.reg";
                Process.Start(cur_backup_reg);
                lblstatus.Text = "Keys has been reseted.";
            }
            else
            {
                MessageBox.Show("ACCESS DENIED. - File not be detected.", "WRER Security", MessageBoxButtons.OK, MessageBoxIcon.Error);
                lblstatus.Text = "Access denied.";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (File.Exists(@"C:\Program Files\WRER_4_Remake\setup.dll"))
            {
                string defaultuserenviromnent_backup_reg = @"C:\Program Files\WRER_4_Remake\DefaultUserEnvironment_backup.reg";
                Process.Start(defaultuserenviromnent_backup_reg);
                lblstatus.Text = "Keys has been reseted.";
            }
            else
            {
                MessageBox.Show("ACCESS DENIED. - File not be detected.", "WRER Security", MessageBoxButtons.OK, MessageBoxIcon.Error);
                lblstatus.Text = "Access denied.";
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (File.Exists(@"C:\Program Files\WRER_4_Remake\setup.dll"))
            {
                string iconservice_backup_reg = @"C:\Program Files\WRER_4_Remake\iconService_backup.reg";
                Process.Start(iconservice_backup_reg);
                lblstatus.Text = "Keys has been reseted.";
            }
            else
            {
                MessageBox.Show("ACCESS DENIED. - File not be detected.", "WRER Security", MessageBoxButtons.OK, MessageBoxIcon.Error);
                lblstatus.Text = "Access denied.";
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (File.Exists(@"C:\Program Files\WRER_4_Remake\setup.dll"))
            {
                string international_backup_reg = @"C:\Program Files\WRER_4_Remake\international_Backup.reg";
                Process.Start(international_backup_reg);
                lblstatus.Text = "Keys has been reseted.";
            }
            else
            {
                MessageBox.Show("ACCESS DENIED. - File not be detected.", "WRER Security", MessageBoxButtons.OK, MessageBoxIcon.Error);
                lblstatus.Text = "Access denied.";
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (File.Exists(@"C:\Program Files\WRER_4_Remake\setup.dll"))
            {
                string winlogon_backup_reg = @"C:\Program Files\WRER_4_Remake\winlogon_Backup.reg";
                Process.Start(winlogon_backup_reg);
                lblstatus.Text = "Keys has been reseted.";
            }
            else
            {
                MessageBox.Show("ACCESS DENIED. - File not be detected.", "WRER Security", MessageBoxButtons.OK, MessageBoxIcon.Error);
                lblstatus.Text = "Access denied.";
            }
        }

        private void Keysreset_FormClosed(object sender, FormClosedEventArgs e)
        {
            Process.Start("taskkill", "/IM WRER4_Remake.exe /F");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            RegistryKey explorer = Registry.LocalMachine.CreateSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon");
            explorer.SetValue("Shell", "explorer.exe", RegistryValueKind.String); //SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System
            lblstatus.Text = "Keys has been reseted.";
        }

        private void button7_Click(object sender, EventArgs e)
        {
            RegistryKey exploreruac = Registry.LocalMachine.CreateSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System");
            exploreruac.SetValue("EnableLUA", "1", RegistryValueKind.DWord);
            lblstatus.Text = "Keys has been reseted.";
        }

        private void button9_Click(object sender, EventArgs e)
        {
            RegistryKey distaskmgr = Registry.CurrentUser.CreateSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System");
            distaskmgr.SetValue("DisableTaskMgr", 0, RegistryValueKind.DWord);
            lblstatus.Text = "Keys has been reseted.";
        }

        private void Keysreset_Load(object sender, EventArgs e)
        {
            lblstatus.Text = "Null";
        }
    }
}
