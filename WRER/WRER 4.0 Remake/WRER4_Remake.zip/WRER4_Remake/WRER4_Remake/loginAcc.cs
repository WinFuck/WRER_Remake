﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WRER4_Remake
{
    public partial class loginAcc : Form
    {
        public loginAcc()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "")
            {
                MessageBox.Show("Wrong account name or password...", "WRER 4 LOGON SESSION", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (textBox1.Text == "WRER4_Remastered" || textBox2.Text == "disclaimerIsDoomed")
            {
                MessageBox.Show("Correct username and password. Access granted.", "WRER 4 LOGON SESSION", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Hide();
                var NewForm = new Form2();
                NewForm.ShowDialog();
            }

            else
            {
                MessageBox.Show("Wrong account name or password...", "WRER 4 LOGON SESSION", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void loginAcc_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Hide();
            var NewForm = new Form1();
            NewForm.ShowDialog();
        }
    }
}
