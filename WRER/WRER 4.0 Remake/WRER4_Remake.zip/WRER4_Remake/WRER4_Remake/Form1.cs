﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WRER4_Remake
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void singinButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            var NewForm = new loginAcc();
            NewForm.ShowDialog();
        }

        private void regButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            var NewForm = new registerAcc();
            NewForm.ShowDialog();
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Process.Start("taskkill", "/IM WRER4_Remake.exe /F");
        }
    }
}
