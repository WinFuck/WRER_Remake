﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WRER4_Remake
{
    public partial class settings : Form
    {
        public settings()
        {
            InitializeComponent();
        }

        private void settings_FormClosed(object sender, FormClosedEventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if(MessageBox.Show("Are you sure for log off?", "WRER 4 Security", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.No)
            {
                Process.Start("taskkill", "/IM WRER4_Remake.exe /F");
            }
            else
            {
                this.Close();
                Application.Exit();
            }
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (File.Exists(@"C:\Program Files\WRER_4_Remake\setup.dll"))
            {
                MessageBox.Show("Sorry, but this option is not available.", "WRER Security", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                MessageBox.Show("ACCESS DENIED. - File not be detected.", "WRER Security", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (File.Exists(@"C:\Program Files\WRER_4_Remake\setup.dll"))
            {
                string tmp_files_cleaner_cmd = @"C:\Program Files\WRER_4_Remake\tmp_files_cleaner.cmd";
                Process.Start(tmp_files_cleaner_cmd);
            }
            else
            {
                MessageBox.Show("ACCESS DENIED. - File not be detected.", "WRER Security", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void Last_Warning()
        {
            if (MessageBox.Show("Are you sure for log off? Im asking u again.", "WRER 4 Security", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.No)
            {
                this.Close();
                Application.Exit();
            }
            else
            {
                Last_Exit();
            }
        }

        public void Last_Exit()
        {
            Process.Start("taskkill", "/IM WRER4_Remake.exe /F");
        }
    }
}
